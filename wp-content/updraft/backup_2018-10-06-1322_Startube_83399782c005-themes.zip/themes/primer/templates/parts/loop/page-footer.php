<?php
/**
 * Template part for displaying the page footer inside The Loop.
 *
 * @package Primer
 * @since   1.0.0
 */

edit_post_link( esc_html__( 'Edit', 'primer' ), '<span class="edit-link">', '</span>' );
